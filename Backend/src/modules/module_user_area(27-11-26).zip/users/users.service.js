import { pool } from '../../../db.js';

export class UsersService {
  /**
   * Fetch users with pagination support (default limit: 10)
   */
  async getAllUsers({ page = 1, limit = 10, search, role } = {}) {
    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.max(1, parseInt(limit, 10) || 10);
    const offset = (pageNum - 1) * limitNum;

    let whereClause = 'WHERE u.is_deleted = 0';
    const params = [];

    if (role && role !== 'all') {
      if (role === 'company' || role === 'admin') {
        whereClause += ' AND (u.role_id = 1 OR u.role = ?)';
        params.push('company');
      } else if (role === 'coordinator') {
        whereClause += ' AND (u.role_id = 2 OR u.role = ?)';
        params.push('coordinator');
      } else if (role === 'branch_head') {
        whereClause += ' AND (u.role_id = 3 OR u.role = ?)';
        params.push('branch_head');
      } else if (role === 'dealer') {
        whereClause += ' AND (u.role_id = 4 OR u.role = ?)';
        params.push('dealer');
      } else {
        whereClause += ' AND u.role = ?';
        params.push(role);
      }
    }

    if (search && search.trim()) {
      const q = `%${search.trim()}%`;
      whereClause += ' AND (u.name LIKE ? OR u.username LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR u.district_name LIKE ?)';
      params.push(q, q, q, q, q);
    }

    // Total active records count
    const [countResult] = await pool.query(
      `SELECT COUNT(*) AS total FROM users u ${whereClause}`,
      params
    );
    const total = Number(countResult?.[0]?.total || 0);

    // Paginated users query directly from users table (without area_assigned join)
    const [rows] = await pool.query(
      `SELECT 
        u.id,
        u.username,
        u.role_id AS roleId,
        u.role,
        u.user_type_id AS userTypeId,
        u.user_type AS userType,
        u.name,
        u.email,
        u.phone,
        u.state_id AS stateId,
        u.state_name AS stateName,
        u.district_id AS districtId,
        u.district_name AS districtName,
        u.address,
        u.is_active AS isActive,
        u.is_deleted AS isDeleted,
        u.created_at AS createdAt
      FROM users u
      ${whereClause}
      ORDER BY u.id ASC
      LIMIT ? OFFSET ?`,
      [...params, limitNum, offset]
    );

    // Enrich rows with distinct assigned district names from area_assigned (supports multi-district assignments)
    if (rows.length > 0) {
      try {
        const userIds = rows.map(r => r.id);
        const [areaDistRows] = await pool.query(
          `SELECT 
             user_id,
             GROUP_CONCAT(DISTINCT district_name ORDER BY district_name ASC SEPARATOR ', ') AS assignedDistrictNames
           FROM area_assigned
           WHERE user_id IN (?) AND district_name IS NOT NULL AND district_name != ''
           GROUP BY user_id`,
          [userIds]
        );
        const distMap = new Map();
        for (const r of (areaDistRows || [])) {
          distMap.set(Number(r.user_id), r.assignedDistrictNames);
        }
        for (const u of rows) {
          const multiDist = distMap.get(Number(u.id));
          if (multiDist) {
            u.districtName = multiDist;
          }
        }
      } catch (e) {
        console.warn('[UsersService] district enrichment warning:', e.message);
      }
    }

    // Role counts across all non-deleted users
    const [roleCountRows] = await pool.query(
      'SELECT role, role_id, COUNT(*) AS count FROM users WHERE is_deleted = 0 GROUP BY role, role_id'
    );
    const roleCounts = {
      all: 0,
      company: 0,
      coordinator: 0,
      branch_head: 0,
      dealer: 0,
      customer: 0
    };
    for (const r of roleCountRows) {
      const cnt = Number(r.count || 0);
      const rId = Number(r.role_id);
      roleCounts.all += cnt;
      if (rId === 1 || r.role === 'company' || r.role === 'admin') {
        roleCounts.company += cnt;
      } else if (rId === 2 || r.role === 'coordinator') {
        roleCounts.coordinator += cnt;
      } else if (rId === 3 || r.role === 'branch_head') {
        roleCounts.branch_head += cnt;
      } else if (rId === 4 || r.role === 'dealer') {
        roleCounts.dealer += cnt;
      } else if (rId === 5 || r.role === 'customer') {
        roleCounts.customer += cnt;
      }
    }

    return {
      rows,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(total / limitNum) || 1,
        roleCounts
      }
    };
  }

  /**
   * Create a new user
   */
  async createUser(data) {
    const {
      username,
      password,
      role = 'customer',
      userType,
      name,
      email,
      phone,
      districtId,
      address,
      areaId,
      areaName
    } = data;

    if (!username || !password || !name) {
      throw new Error('Username, password, and name are required.');
    }

    // Check if username already exists
    const [existing] = await pool.query(
      'SELECT id, is_deleted FROM users WHERE username = ? LIMIT 1',
      [username.trim()]
    );
    if (existing && existing.length > 0 && existing[0].is_deleted === 0) {
      throw new Error('User already exists');
    }

    // Role mapping
    const roleMap = {
      company: { roleId: 1, role: 'company', userTypeId: 1, userType: 'admin' },
      admin: { roleId: 1, role: 'company', userTypeId: 1, userType: 'admin' },
      coordinator: { roleId: 2, role: 'coordinator', userTypeId: 2, userType: 'staff' },
      branch_head: { roleId: 3, role: 'branch_head', userTypeId: 2, userType: 'staff' },
      dealer: { roleId: 4, role: 'dealer', userTypeId: null, userType: null },
      customer: { roleId: 5, role: 'customer', userTypeId: null, userType: null }
    };

    const mapped = roleMap[role.toLowerCase()] || {
      roleId: 5,
      role: 'customer',
      userTypeId: null,
      userType: null
    };

    let resolvedDistrictName = null;
    const rawCreateDistIds = Array.isArray(data.districtIds) ? data.districtIds : [];
    const fallbackCreateDistId = rawCreateDistIds.map(d => Number(d)).find(d => !isNaN(d) && d > 0) || null;
    let resolvedDistrictId = districtId ? Number(districtId) : fallbackCreateDistId;

    if (resolvedDistrictId) {
      const [distRows] = await pool.query('SELECT name FROM districts WHERE id = ?', [resolvedDistrictId]);
      if (distRows && distRows.length > 0) {
        resolvedDistrictName = distRows[0].name ? distRows[0].name.trim() : null;
      }
    }

    // Extract list of area IDs (supports both areaIds array and areaId single/array)
    const rawAreaIds = Array.isArray(data.areaIds) ? data.areaIds : (Array.isArray(areaId) ? areaId : (areaId ? [areaId] : []));
    const cleanAreaIds = rawAreaIds.map(id => Number(id)).filter(id => !isNaN(id) && id > 0);

    // If areaIds are provided, ensure no other active user is assigned to any of these areas
    if (cleanAreaIds.length > 0) {
      try {
        const [dupArea] = await pool.query(
          `SELECT aa.area_name, aa.user_name, u.name 
           FROM area_assigned aa
           LEFT JOIN users u ON u.id = aa.user_id
           WHERE aa.area_id IN (?) AND aa.user_id != ? AND (u.is_deleted = 0 OR u.is_deleted IS NULL)
           LIMIT 1`,
          [cleanAreaIds, existing && existing.length > 0 ? existing[0].id : 0]
        );
        if (dupArea && dupArea.length > 0) {
          throw new Error(`Area "${dupArea[0].area_name}" is already assigned to another Branch Head (${dupArea[0].name || dupArea[0].user_name}).`);
        }
      } catch (err) {
        if (err.message && err.message.includes('Area')) throw err;
      }
    } else if ((mapped.roleId === 3 || mapped.role === 'branch_head') && resolvedDistrictId) {
      const [duplicateBranchHeads] = await pool.query(
        `SELECT id, name FROM users 
         WHERE (role_id = 3 OR role = 'branch_head') 
           AND district_id = ? 
           AND is_deleted = 0 
           AND id != ?
         LIMIT 1`,
        [resolvedDistrictId, existing && existing.length > 0 ? existing[0].id : 0]
      );
      if (duplicateBranchHeads && duplicateBranchHeads.length > 0) {
        throw new Error(`District already has an assigned Branch Head (${duplicateBranchHeads[0].name}).`);
      }
    }

    let targetUserId;
    if (existing && existing.length > 0 && existing[0].is_deleted === 1) {
      targetUserId = existing[0].id;
      await pool.query(
        `UPDATE users SET 
          password = ?,
          role_id = ?,
          role = ?,
          user_type_id = ?,
          user_type = ?,
          name = ?,
          email = ?,
          phone = ?,
          state_id = 1,
          state_name = 'Kerala',
          district_id = ?,
          district_name = ?,
          address = ?,
          is_active = 1,
          is_deleted = 0,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?`,
        [
          password,
          mapped.roleId,
          mapped.role,
          userType === 'admin' ? 1 : (mapped.userTypeId || null),
          userType || mapped.userType || null,
          name.trim(),
          email ? email.trim() : null,
          phone ? phone.trim() : null,
          resolvedDistrictId,
          resolvedDistrictName,
          address ? address.trim() : null,
          targetUserId
        ]
      );
    } else {
      const [result] = await pool.query(
        `INSERT INTO users (
          username,
          password,
          role_id,
          role,
          user_type_id,
          user_type,
          name,
          email,
          phone,
          state_id,
          state_name,
          district_id,
          district_name,
          address,
          is_active,
          is_deleted
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'Kerala', ?, ?, ?, 1, 0)`,
        [
          username.trim(),
          password,
          mapped.roleId,
          mapped.role,
          userType === 'admin' ? 1 : (mapped.userTypeId || null),
          userType || mapped.userType || null,
          name.trim(),
          email ? email.trim() : null,
          phone ? phone.trim() : null,
          resolvedDistrictId,
          resolvedDistrictName,
          address ? address.trim() : null
        ]
      );
      targetUserId = result.insertId;
    }

    // Save into area_assigned if areas are specified
    if (cleanAreaIds.length > 0 && targetUserId) {
      try {
        await this._syncUserAssignedAreas(
          targetUserId,
          name.trim(),
          resolvedDistrictId,
          resolvedDistrictName,
          cleanAreaIds,
          areaName
        );
      } catch (e) {
        console.warn('[UsersService] area_assigned insert warning:', e.message);
      }
    }

    let createdUser;
    try {
      const [rows] = await pool.query(
        `SELECT 
          u.id,
          u.username,
          u.role_id AS roleId,
          u.role,
          u.user_type_id AS userTypeId,
          u.user_type AS userType,
          u.name,
          u.email,
          u.phone,
          u.state_id AS stateId,
          u.state_name AS stateName,
          u.district_id AS districtId,
          u.district_name AS districtName,
          GROUP_CONCAT(DISTINCT aa.area_id) AS areaId,
          GROUP_CONCAT(DISTINCT aa.area_name SEPARATOR ', ') AS areaName,
          u.address,
          u.is_active AS isActive,
          u.created_at AS createdAt
        FROM users u
        LEFT JOIN area_assigned aa ON aa.user_id = u.id
        WHERE u.id = ?
        GROUP BY u.id`,
        [targetUserId]
      );
      createdUser = rows[0];
    } catch {
      const [rows] = await pool.query(
        `SELECT 
          u.id,
          u.username,
          u.role_id AS roleId,
          u.role,
          u.user_type_id AS userTypeId,
          u.user_type AS userType,
          u.name,
          u.email,
          u.phone,
          u.state_id AS stateId,
          u.state_name AS stateName,
          u.district_id AS districtId,
          u.district_name AS districtName,
          u.address,
          u.is_active AS isActive,
          u.created_at AS createdAt
        FROM users u
        WHERE u.id = ?`,
        [targetUserId]
      );
      createdUser = rows[0];
    }

    return createdUser;
  }

  /**
   * Update an existing user
   */
  async updateUser(id, data) {
    const {
      name,
      email,
      phone,
      districtId,
      address,
      role,
      userType,
      password,
      areaId,
      areaName
    } = data;

    let resolvedDistrictName = null;
    const rawUpdateDistIds = Array.isArray(data.districtIds) ? data.districtIds : [];
    const fallbackUpdateDistId = rawUpdateDistIds.map(d => Number(d)).find(d => !isNaN(d) && d > 0) || null;
    let resolvedDistrictId = districtId !== undefined
      ? (districtId ? Number(districtId) : fallbackUpdateDistId)
      : (fallbackUpdateDistId || undefined);

    const rawAreaIds = Array.isArray(data.areaIds) ? data.areaIds : (Array.isArray(areaId) ? areaId : (areaId ? [areaId] : []));
    const cleanAreaIds = rawAreaIds.map(aId => Number(aId)).filter(aId => !isNaN(aId) && aId > 0);

    if (cleanAreaIds.length > 0) {
      try {
        const [dupArea] = await pool.query(
          `SELECT aa.area_name, aa.user_name, u.name 
           FROM area_assigned aa
           LEFT JOIN users u ON u.id = aa.user_id
           WHERE aa.area_id IN (?) AND aa.user_id != ? AND (u.is_deleted = 0 OR u.is_deleted IS NULL)
           LIMIT 1`,
          [cleanAreaIds, id]
        );
        if (dupArea && dupArea.length > 0) {
          throw new Error(`Area "${dupArea[0].area_name}" is already assigned to another Branch Head (${dupArea[0].name || dupArea[0].user_name}).`);
        }
      } catch (err) {
        if (err.message && err.message.includes('Area')) throw err;
      }
    }

    if (resolvedDistrictId) {
      const [distRows] = await pool.query('SELECT name FROM districts WHERE id = ?', [resolvedDistrictId]);
      if (distRows && distRows.length > 0) {
        resolvedDistrictName = distRows[0].name ? distRows[0].name.trim() : null;
      }

      // Check current or updated role of user
      let isBranchHead = role ? (role.toLowerCase() === 'branch_head') : false;
      if (!role) {
        const [currentUser] = await pool.query('SELECT role, role_id FROM users WHERE id = ?', [id]);
        if (currentUser && currentUser.length > 0) {
          isBranchHead = currentUser[0].role_id === 3 || currentUser[0].role === 'branch_head';
        }
      }

      if (cleanAreaIds.length === 0 && isBranchHead) {
        const [duplicateBranchHeads] = await pool.query(
          `SELECT id, name FROM users 
           WHERE (role_id = 3 OR role = 'branch_head') 
             AND district_id = ? 
             AND is_deleted = 0 
             AND id != ?
           LIMIT 1`,
          [resolvedDistrictId, id]
        );
        if (duplicateBranchHeads && duplicateBranchHeads.length > 0) {
          throw new Error(`District already has an assigned Branch Head (${duplicateBranchHeads[0].name}).`);
        }
      }
    }

    const updates = [];
    const values = [];

    if (name !== undefined) {
      updates.push('name = ?');
      values.push(name.trim());
    }
    if (email !== undefined) {
      updates.push('email = ?');
      values.push(email ? email.trim() : null);
    }
    if (phone !== undefined) {
      updates.push('phone = ?');
      values.push(phone ? phone.trim() : null);
    }
    if (resolvedDistrictId !== undefined) {
      updates.push('district_id = ?, district_name = ?');
      values.push(resolvedDistrictId, resolvedDistrictName);
    }
    if (address !== undefined) {
      updates.push('address = ?');
      values.push(address ? address.trim() : null);
    }
    if (role !== undefined) {
      const roleMap = {
        company: { roleId: 1, role: 'company' },
        admin: { roleId: 1, role: 'company' },
        coordinator: { roleId: 2, role: 'coordinator' },
        branch_head: { roleId: 3, role: 'branch_head' },
        dealer: { roleId: 4, role: 'dealer' },
        customer: { roleId: 5, role: 'customer' }
      };
      const mapped = roleMap[role.toLowerCase()];
      if (mapped) {
        updates.push('role_id = ?, role = ?');
        values.push(mapped.roleId, mapped.role);
      }
    }
    if (userType !== undefined) {
      updates.push('user_type = ?');
      values.push(userType || null);
    }
    if (password) {
      updates.push('password = ?');
      values.push(password);
    }

    if (updates.length > 0) {
      values.push(id);
      await pool.query(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, values);
    }

    // Save/update area_assigned if areaIds or areaId is specified
    if (data.areaIds !== undefined || areaId !== undefined) {
      try {
        const [uRows] = await pool.query('SELECT name, district_id, district_name FROM users WHERE id = ?', [id]);
        const uData = uRows?.[0] || {};
        const uName = name ? name.trim() : uData.name;
        const uDistId = resolvedDistrictId || uData.district_id;
        const uDistName = resolvedDistrictName || uData.district_name;

        await this._syncUserAssignedAreas(id, uName, uDistId, uDistName, cleanAreaIds, areaName);
      } catch (e) {
        console.warn('[UsersService] area_assigned update warning:', e.message);
      }
    }

    let updatedUser;
    try {
      const [rows] = await pool.query(
        `SELECT 
          u.id,
          u.username,
          u.role_id AS roleId,
          u.role,
          u.user_type_id AS userTypeId,
          u.user_type AS userType,
          u.name,
          u.email,
          u.phone,
          u.state_id AS stateId,
          u.state_name AS stateName,
          u.district_id AS districtId,
          u.district_name AS districtName,
          GROUP_CONCAT(DISTINCT aa.area_id) AS areaId,
          GROUP_CONCAT(DISTINCT aa.area_name SEPARATOR ', ') AS areaName,
          u.address,
          u.is_active AS isActive,
          u.created_at AS createdAt
        FROM users u
        LEFT JOIN area_assigned aa ON aa.user_id = u.id
        WHERE u.id = ?
        GROUP BY u.id`,
        [id]
      );
      updatedUser = rows[0];
    } catch {
      const [rows] = await pool.query(
        `SELECT 
          u.id,
          u.username,
          u.role_id AS roleId,
          u.role,
          u.user_type_id AS userTypeId,
          u.user_type AS userType,
          u.name,
          u.email,
          u.phone,
          u.state_id AS stateId,
          u.state_name AS stateName,
          u.district_id AS districtId,
          u.district_name AS districtName,
          u.address,
          u.is_active AS isActive,
          u.created_at AS createdAt
        FROM users u
        WHERE u.id = ?`,
        [id]
      );
      updatedUser = rows[0];
    }

    return updatedUser;
  }

  /**
   * Toggle user active/inactive status
   */
  async toggleStatus(id) {
    // Check if activating an inactive branch head causes a district conflict
    const [conflicts] = await pool.query(
      `SELECT 
        active_user.id AS active_user_id,
        active_user.name AS active_user_name,
        d.name AS district_name
      FROM users target_user
      INNER JOIN users active_user 
        ON active_user.district_id = target_user.district_id
        AND active_user.role_id = 3
        AND active_user.is_active = 1
        AND active_user.is_deleted = 0
        AND active_user.id != target_user.id
      INNER JOIN districts d 
        ON d.id = target_user.district_id
      WHERE target_user.id = ?
        AND target_user.role_id = 3
        AND target_user.is_active = 0
        AND target_user.is_deleted = 0
      LIMIT 1`,
      [id]
    );

    if (conflicts.length > 0) {
      const conflict = conflicts[0];
      const error = new Error(
        `District "${conflict.district_name}" is already assigned to active Branch Head "${conflict.active_user_name}". Please inactivate that user first or assign this user to a different district.`
      );
      error.statusCode = 400;
      throw error;
    }

    await pool.query(
      'UPDATE users SET is_active = IF(is_active = 1, 0, 1) WHERE id = ?',
      [id]
    );

    const [rows] = await pool.query(
      'SELECT id, username, name, is_active AS isActive FROM users WHERE id = ?',
      [id]
    );
    return rows[0];
  }

  /**
   * Soft delete a user (set is_deleted = 1)
   */
  async deleteUser(id) {
    await pool.query(
      'UPDATE users SET is_deleted = 1 WHERE id = ?',
      [id]
    );
    try {
      await pool.query('DELETE FROM area_assigned WHERE user_id = ?', [id]);
    } catch (e) {
      console.warn('[UsersService] area_assigned delete warning on deleteUser:', e.message);
    }
    return { success: true, id };
  }

  /**
   * Fetch available districts for Branch Head
   */
  /**
   * Fetch Branch Heads for status update modal with pagination
   */
  async getBranchHeadsForStatusUpdate(search = null, page = 1, limit = 20) {
    const cleanSearch = search ? String(search).trim() : null;
    const cleanPage = page ? Math.max(1, Number(page)) : 1;
    const cleanLimit = limit ? Math.max(1, Number(limit)) : 20;

    const [results] = await pool.query(
      'CALL get_branch_heads_for_status_update(?, ?, ?)',
      [cleanSearch, cleanPage, cleanLimit]
    );
    return results?.[0] || [];
  }

  async getAvailableBranchDistricts(userId = null) {
    const idParam = userId ? Number(userId) : null;
    const [results] = await pool.query('CALL get_available_branch_districts(?)', [idParam]);
    return results?.[0] || [];
  }

  /**
   * Synchronize a user's area_assigned rows while preserving each area's own district metadata.
   */
  async _syncUserAssignedAreas(userId, userName, fallbackDistrictId, fallbackDistrictName, cleanAreaIds, fallbackAreaName = null) {
    if (!userId) return;
    if (!cleanAreaIds || cleanAreaIds.length === 0) {
      await pool.query('DELETE FROM area_assigned WHERE user_id = ?', [userId]);
      return;
    }

    await pool.query('DELETE FROM area_assigned WHERE user_id = ? AND area_id NOT IN (?)', [userId, cleanAreaIds]);

    const [areaRows] = await pool.query(
      `SELECT a.id, a.name, a.pincode, a.district_id, d.name AS district_name
       FROM areas a
       LEFT JOIN districts d ON a.district_id = d.id
       WHERE a.id IN (?)`,
      [cleanAreaIds]
    );
    const areaMap = new Map();
    for (const a of (areaRows || [])) {
      areaMap.set(Number(a.id), a);
    }

    for (const aId of cleanAreaIds) {
      const aData = areaMap.get(Number(aId));
      const finalAreaName = aData?.name || fallbackAreaName || null;
      const finalPincode = aData?.pincode || null;
      const finalDistrictId = aData?.district_id ? Number(aData.district_id) : fallbackDistrictId;
      const finalDistrictName = aData?.district_name || fallbackDistrictName || null;
      await pool.query(
        `INSERT INTO area_assigned (user_id, user_name, district_id, district_name, area_id, area_name, area_pincode)
         VALUES (?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE 
           user_name = VALUES(user_name),
           district_id = VALUES(district_id),
           district_name = VALUES(district_name),
           area_id = VALUES(area_id),
           area_name = VALUES(area_name),
           area_pincode = VALUES(area_pincode)`,
        [userId, userName, finalDistrictId, finalDistrictName, Number(aId), finalAreaName, finalPincode]
      );
    }
  }

  /**
   * Fetch assigned area IDs for a specific user (on edit user)
   */
  async getUserAssignedAreas(userId) {
    if (!userId) return [];
    const [rows] = await pool.query(
      'SELECT area_id, area_name, district_id, district_name FROM area_assigned WHERE user_id = ? ORDER BY district_name ASC, area_name ASC',
      [Number(userId)]
    );
    return rows || [];
  }
}

export const usersService = new UsersService();
